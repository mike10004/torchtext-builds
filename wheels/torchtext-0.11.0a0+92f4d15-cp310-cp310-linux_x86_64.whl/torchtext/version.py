__version__ = '0.11.0a0+92f4d15'
git_version = '92f4d158d8cbe9136896befa2d4234ea8b8e2795'
